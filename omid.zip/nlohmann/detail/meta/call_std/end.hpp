#pragma once

#include <nlohmann/detail/macro_scope.hpp>

namespace nlohmann
{
NLOHMANN_CAN_CALL_STD_FUNC_IMPL(end);
}  // namespace nlohmann
